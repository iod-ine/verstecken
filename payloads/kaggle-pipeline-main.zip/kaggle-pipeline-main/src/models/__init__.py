"""This submodule contains functions and scripts that train and evaluate models."""
