"""This submodule contains functions and scripts that manipulate data."""
