To run executable scripts, from the project root do

``` shell
python -m src.submodule.script
```
