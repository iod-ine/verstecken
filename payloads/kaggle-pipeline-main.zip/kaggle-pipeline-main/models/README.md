This folder contains trained and serialized models, predictions, and summaries.
