This folder contains intermediate data that has been transformed.
