This folder contains data from third party sources.
