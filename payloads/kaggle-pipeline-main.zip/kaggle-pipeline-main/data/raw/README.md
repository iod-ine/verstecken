This folder contains the original, immutable data.
